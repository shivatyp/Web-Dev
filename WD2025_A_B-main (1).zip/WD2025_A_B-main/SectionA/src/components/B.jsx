import React from 'react'
import C from './C'

const B = () => {
  return (
    <div>
          <h2> B Compoment</h2>
          <C/>
      </div>
  )
}

export default B