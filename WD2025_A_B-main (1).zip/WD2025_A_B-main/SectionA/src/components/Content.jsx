import React from 'react'

const Content = () => {
  return (
      <div>
          <p>This is content, body part</p>
      </div>
  )
}

export default Content