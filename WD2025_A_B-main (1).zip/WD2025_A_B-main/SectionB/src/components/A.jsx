import React from 'react'
import B from "./B"
const A = () => {
  return (
      <div>
          <h2>Component A</h2>
          <B/>
      </div>
  )
}

export default A