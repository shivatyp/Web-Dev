import React from 'react'

const JavaCom = () => {
  return (
    <div>
      <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Magnam maxime fuga quas. Corporis cum, ex animi ratione nostrum excepturi impedit! Nobis ex quod quibusdam repellat totam sequi fugiat culpa quia.</p>
    <p>Excepturi nobis veniam praesentium vel ratione dolorum eaque impedit illum quod quisquam atque error, facere ipsum suscipit exercitationem iste sapiente tempore eligendi adipisci debitis quia. Officiis ut delectus placeat similique.</p>
      <p>Vero ipsum repudiandae vel corrupti impedit! Autem, aliquid? Rerum voluptas similique dolorem enim rem dignissimos, consequuntur a nisi impedit animi itaque unde! Omnis aut sit eius molestias hic, veniam tenetur.
        </p>
    </div>
  )
}

export default JavaCom