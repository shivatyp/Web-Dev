
const Footer = () => {
  return (
      <div className="btn btn-warning w-100">
          <i>@Copyright:</i> <b>MCA KIET</b>
      </div>
  )
}

export default Footer