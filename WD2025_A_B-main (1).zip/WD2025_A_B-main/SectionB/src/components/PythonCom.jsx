import React from 'react'

const PythonCom = () => {
  return (
    <div>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Inventore, nam? Rem ipsa culpa quaerat odio placeat, nisi, quas dolores mollitia numquam omnis autem libero officiis repudiandae sapiente, quidem suscipit adipisci?</div>
  )
}

export default PythonCom